<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGerechtsoortenTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('gerechtsoorten', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique()->nullable();
            $table->string('naam')->nullable();
            $table->unsignedBigInteger('gerechtcategorie_id');
            $table->foreign('gerechtcategorie_id')->references('id')->on('gerechtcategorien');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('gerechtsoorten');
    }
}
