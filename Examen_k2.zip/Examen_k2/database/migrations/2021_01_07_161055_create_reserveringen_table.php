<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateReserveringenTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('reserveringen', function (Blueprint $table) {
            $table->id();
            $table->integer('tafel');
            $table->date('datum');
            $table->time('tijd');
            $table->unsignedBigInteger('klant_id');
            $table->foreign('klant_id')->references('id')->on('klanten');
            $table->integer('aantal');
            $table->tinyInteger('status')->default(1);
            $table->timestamp('datum_toegevoegd');
            $table->integer('aantal_k')->default(0);
            $table->text('allergieen')->nullable();
            $table->text('opmerkingen')->nullable();
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('reserveringen');
    }
}
