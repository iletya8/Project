<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBestellingenTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bestellingen', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('reservering_id');
            $table->foreign('reservering_id')->references('id')->on('reserveringen');
            $table->unsignedBigInteger('menuitem_id');
            $table->foreign('menuitem_id')->references('id')->on('menuitems');
            $table->integer('aantal');
            $table->tinyInteger('gereserveerd')->default(0)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bestellingen');
    }
}
