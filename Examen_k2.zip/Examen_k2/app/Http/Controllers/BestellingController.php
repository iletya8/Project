<?php

namespace App\Http\Controllers;

use App\Bestelling;
use App\Reservering;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BestellingController extends Controller
{
    public function indexkok() 
    {
        $bestellingen = Bestelling::all();

        return view('kok', ['bestellingen' => $bestellingen]);
    }
    public function indexbarman() 
    {
        $bestellingen = Bestelling::all();

        return view('kok', ['bestellingen' => $bestellingen]);
    }
    public function show($id)
    {
        $bestellingen = Bestelling::all()->where('id', $id);
        $reserveringen = Reservering::all()->where('id', $id);
        return view('ober', ['bestellingen' => $bestellingen], ['reserveringen' => $reserveringen]);
    }
}
