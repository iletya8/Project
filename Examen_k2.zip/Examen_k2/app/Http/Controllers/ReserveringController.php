<?php

namespace App\Http\Controllers;
use Carbon\Carbon;
use App\Reservering;
use App\Klant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReserveringController extends Controller
{
    
    public function index() 
    {
        $reserveringen = Reservering::all();
        $klanten = Klant::all();
    
        return view('reserveringen', ['reserveringen' => $reserveringen], ['klanten' => $klanten]);
    }
    public function edit(Request $request)
    {
        $reserveringen = Reservering::all();
        $klanten = Klant::all()->toArray();
        $datum = $request->input('datum');
        $tijd = $request->input('tijd');
        $tafel = $request->input('tafel');
        $naam = $request->input('naam');
        $telefoon = $request->input('telefoon');
        $aantal = $request->input('aantal');
        $id = $request->input('id');
        DB::update('update reserveringen set datum = ?,tijd=?,tafel=?,aantal=? where id = ?',[$datum,$tijd,$tafel,$aantal,$id]);
        DB::update('update klanten set naam = ?,telefoon=? where id = ?',[$naam,$telefoon,$id]);

        return redirect()->back();
    }
    public function toevoegen() 
    {
        return view('reservering_toevoegen');
    }
    public function datatoevoegen(Request $request)
    {
        // $this->validate($request, [
        //     'naam' => 'required',
        //     'telefoon' => 'required',
        //     'email' => 'required',
        //     'tafel' => 'required',
        //     'datum' => 'required',
        //     'tijd' => 'required',
        //     'aantal' => 'required',
        //     'allergieen' => 'required',
        //     'opmerkingen' => 'required',
        //      'klant_id' => 'required'
        // ]);
        $klant = Klant::create([
            'naam' => $request->input('naam'),
            'telefoon' => $request->input('telefoon'),
            'email' => $request->input('email'),
            'straat' => $request->input('straat'),
            'huisnummer' => $request->input('huisnummer'),
            'toevoeging' => $request->input('toevoeging'),
            'postcode' => $request->input('postcode'),
            'woonplaats' => $request->input('woonplaats'),
            'land' => $request->input('land'),

        ]);
        $klantid = $klant->id; 
        $reservering = Reservering::create([
            'tafel' => $request->input('tafel'),
            'datum' => $request->input('datum'),
            'tijd' => $request->input('tijd'),
            'aantal' => $request->input('aantal'),
            'allergieen' => $request->input('allergieen'),
            'opmerkingen' => $request->input('opmerkingen'),
            'klant_id' => $klantid
         
        ]);
        return redirect('/reserveringen');
    }
}
