<?php

namespace App\Http\Controllers;
use App\Klant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KlantController extends Controller
{

}
