<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Klant extends Model
{
    protected $table = 'klanten';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'naam',
        'telefoon',
        'email',
        'straat',
        'huisnummer',
        'toevoeging',
        'postcode',
        'woonplaats',
        'land'
   ];

    public function Reservering() {
        return $this->hasOne(Reservering::class);
    }
}
