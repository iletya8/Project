<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bestelling extends Model
{
    protected $table = 'bestellingen';
    protected $primaryKey = 'id';
    protected $guarded = []; 
    public $timestamps = false;
}
