<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reservering extends Model
{
    protected $table = 'reserveringen';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'tafel',
        'datum',
        'tijd',
        'aantal',
        'allergieen',
        'opmerkingen',
        'klant_id'
   ];
}
