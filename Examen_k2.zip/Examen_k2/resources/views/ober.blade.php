<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kok</title>
    <style>
  table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  align: center;
}
th, td {
    text-align: center;
}
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: white;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}
    </style>
</head>
<body>
<div style="background-color: white; border: 1px solid grey; width: 100%; padding: 25px; height:10px; margin-top: 0%;">
    <a style="color: grey; padding-right: 5px;">Home</a>
    <a href="{{ url('/reserveringen') }}" style="color: grey; padding-right: 5px;">Reserveringen</a>
    <div class="dropdown">
  <a style="color: grey; padding-right: 5px;">Serveren ▼</a>
  <div class="dropdown-content">
  <p>Voor kok</p>
  <p>Voor Barman</p>
  <p>Voor Ober</p>
  </div>
</div>
<div class="dropdown">
  <a style="color: grey; padding-right: 5px;">Gegevens ▼</a>
  <div class="dropdown-content">
  <p>Drinken</p>
  <p>Eten</p>
  <p>Klanten</p>
  <p>Gerecht hoofdgroepen</p>
  <p>Gerecht subgroepen</p>
  </div>
</div>
    </div>
    @if(count($reserveringen) > 0)

@foreach ($reserveringen as $res)
    <h4> Neem bestelling op voor tafel {{$res->tafel}}</h4>
    @endforeach
@else
    Er zijn geen reserveringen
    @endif 
<table style="width:70%">
<tr>
<th>Artikel</th>
<th>#</th>
<th>Prijs</th>
<th>Totaal</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
@if(count($bestellingen) > 0)

@foreach ($bestellingen as $bes)
<td>Biefstuk</td>
<td>2</td>
<td>$11</td>
<td>$22</td>
<td>+</td>
<td>-</td>
<td><img style="width: 10px; height: 10px;" src="{{ URL::to('/assets/trash.png') }}"></td>
</tr>
@endforeach
@else
    Er zijn geen bestellingen
    @endif 
</table>
</body>
</html>