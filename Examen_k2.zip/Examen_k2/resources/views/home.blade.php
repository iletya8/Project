<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <style>
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: white;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}</style>
</head>
<body style="background-color: lightgrey; margin: 0%; padding: 0%;">
    <div style="background-color: white; border: 1px solid grey; width: 100%; padding: 25px; height:10px; margin-top: 0%;">
    <a style="color: grey; padding-right: 5px;">Home</a>
    <a href="{{ url('/reserveringen') }}" style="color: grey; padding-right: 5px;">Reserveringen</a>
    <div class="dropdown">
  <a style="color: grey; padding-right: 5px;">Serveren ▼</a>
  <div class="dropdown-content">
  <a href="{{ url('/kok') }}">Voor kok</a>
  <a href="{{ url('/barman') }}">Voor Barman</a>
  <a href="{{ url('/reserveringen') }}">Voor Ober</a>
  </div>
</div>
<div class="dropdown">
  <a style="color: grey; padding-right: 5px;">Gegevens ▼</a>
  <div class="dropdown-content">
  <p>Drinken</p>
  <p>Eten</p>
  <p>Klanten</p>
  <p>Gerecht hoofdgroepen</p>
  <p>Gerecht subgroepen</p>
  </div>
</div>
    </div>
    <div>
    <h4>Welkom bij de reserverings en bestellingenapplicatie van Restaurant Excellent Taste.</h4>
   
    <h4>Vul eerst een reservering in. Deze kan telefonisch binnenkomen of kan worden ingevoerd als gasten plaatsnemen aan een vrije tafel.</h4>
    
    <h4>Daarna kan een bestelling worden opgenomen.</h4>
    <img src="{{ URL::to('/assets/excellent.png') }}">
     </div>
</body>
</html>