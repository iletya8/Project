<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reservering toevoegen</title>
    <style>
        table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
        align: center;
      }
      th, td {
          text-align: center;
      }
          </style>
</head>
<body>
    <form action="<?php echo e(url('/reserveringen/datatoevoegen')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <h1> Reservering toevoegen</h1>
    <h3>Klantgegevens:</h3>
    <a>Klantnaam<a>
    <input required name="naam" value=""/> <br/>
    <a>Telefoon<a>
    <input required name="telefoon" value=""/> <br/>
    <a>Email<a>
   <input required name="email" value=""/>
   <br/>
    <a>Straat<a>
   <input required name="straat" value=""/> <br/>
   <a>Huisnummer<a>
    <input required name="huisnummer" value=""/> <br/>
    <a>Toevoeging<a>
        <input name="toevoeging" value=""/> <br/>
    <a>Postcode<a>
    <input required name="postcode" value=""/> <br/>
    <a>Woonplaats<a>
     <input required name="woonplaats" value=""/> <br/>
     <a>Land<a>
    <input required name="land" value=""/>
        
   <h3>Reserveringgegevens:</h3>
   <a>Tafel<a>
   <input required name="tafel" value=""/> <br/>
   <a>Datum<a>
   <input required name="datum" value=""/> <br/>
   <a>Tijd<a>
   <input required name="tijd" value=""/> <br/>
   <a>Aantal<a>
  <input required name="aantal" value=""/><br/>
  <a>Allergieen<a>
   <input required name="allergieen" value=""/><br/>
   <a>Opmerkingen<a>
  <input required name="opmerkingen" value=""/><br/>
    <br/>
    
    <input type='submit' value="Voeg reservering toe" />
    </form>
    </body>
</html><?php /**PATH D:\exam\Examen_k2\resources\views/reservering_toevoegen.blade.php ENDPATH**/ ?>