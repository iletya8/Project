<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserveringen</title>
    <style>
  table, th, td {
  border: 1px solid black !important;
  border-collapse: collapse;
  align: center;
}
th, td {
    text-align: center;
}
td {
    background-color: white;
}
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: white;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}
input { 
    text-align: center; 
    background-color: white;
    border: 1px solid white;
}
.tableinput {
    background-color: white !important;
    border: 1px solid white !important;
}
    </style>
</head>
<body>
<div style="background-color: white; border: 1px solid grey; width: 100%; padding: 25px; height:10px; margin-top: 0%;">
    <a style="color: grey; padding-right: 5px;">Home</a>
    <a href="<?php echo e(url('/reserveringen')); ?>" style="color: grey; padding-right: 5px;">Reserveringen</a>
    <div class="dropdown">
  <a style="color: grey; padding-right: 5px;">Serveren ▼</a>
  <div class="dropdown-content">
  <p>Voor kok</p>
  <p>Voor Barman</p>
  <p>Voor Ober</p>
  </div>
</div>
<div class="dropdown">
  <a style="color: grey; padding-right: 5px;">Gegevens ▼</a>
  <div class="dropdown-content">
  <p>Drinken</p>
  <p>Eten</p>
  <p>Klanten</p>
  <p>Gerecht hoofdgroepen</p>
  <p>Gerecht subgroepen</p>
  </div>
</div>
    </div>
    <h4> Klik op het tafelnummer om een bestelling te maken.</h4>
    <h4> | rood = verleden | groen = vandaag | oranje = toekomst |</h4>
<table style="width:70%">
<tr>
<th>Datum</th>
<th>Tijd</th>
<th>Tafel</th>
<th>Klantnaam</th>
<th>Telefoonnummer</th>
<th>Aantal</th>
<th><a href="<?php echo e(url('/reserveringen/toevoegen/')); ?>">+</a></th>
<th></th>

</tr>
<?php if(count($klanten) > 0): ?>
<?php $__currentLoopData = $klanten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $klant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(url('/reserveringen/edit')); ?>" method="post">
<?php echo csrf_field(); ?>
<tr>
<input name="id" type="hidden" value="<?php echo e($klant->Reservering->id); ?>"/>
<td><input name="datum" value="<?php echo e($klant->Reservering->datum); ?>"/></td>
<td><input name="tijd" value="<?php echo e($klant->Reservering->tijd); ?>"/></td>
<td style="background-color: white !important; "><input class="tableinput" href="<?php echo e(url('/ober/' . $klant->Reservering->id)); ?>" name="tafel" value="<?php echo e($klant->Reservering->tafel); ?>"></input></td>
<td><input name="naam" value="<?php echo e($klant->naam); ?>"/></td>
<td><input name="telefoon" value="<?php echo e($klant->telefoon); ?>"/></td>
<td><input name="aantal" value="<?php echo e($klant->Reservering->aantal); ?>"/></td>
<td> <input type="image" style="width: 10px; height: 10px;" src="<?php echo e(URL::to('/assets/pencil.svg')); ?>" alt="Submit" />  </td>
<td><img style="width: 10px; height: 10px;" src="<?php echo e(URL::to('/assets/trash.png')); ?>"></td>
</tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    Er zijn geen reserveringen
    <?php endif; ?> 
    </table>
    </form>
</body>
</html><?php /**PATH D:\exam\Examen_k2\resources\views/reserveringen.blade.php ENDPATH**/ ?>