<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kok</title>
    <style>
  table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  align: center;
}
th, td {
    text-align: center;
}
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: white;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}
    </style>
</head>
<body>
<div style="background-color: white; border: 1px solid grey; width: 100%; padding: 25px; height:10px; margin-top: 0%;">
    <a style="color: grey; padding-right: 5px;">Home</a>
    <a href="<?php echo e(url('/reserveringen')); ?>" style="color: grey; padding-right: 5px;">Reserveringen</a>
    <div class="dropdown">
  <a style="color: grey; padding-right: 5px;">Serveren ▼</a>
  <div class="dropdown-content">
  <p>Voor kok</p>
  <p>Voor Barman</p>
  <p>Voor Ober</p>
  </div>
</div>
<div class="dropdown">
  <a style="color: grey; padding-right: 5px;">Gegevens ▼</a>
  <div class="dropdown-content">
  <p>Drinken</p>
  <p>Eten</p>
  <p>Klanten</p>
  <p>Gerecht hoofdgroepen</p>
  <p>Gerecht subgroepen</p>
  </div>
</div>
    </div>
    <?php if(count($reserveringen) > 0): ?>

<?php $__currentLoopData = $reserveringen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h4> Neem bestelling op voor tafel <?php echo e($res->tafel); ?></h4>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    Er zijn geen reserveringen
    <?php endif; ?> 
<table style="width:70%">
<tr>
<th>Artikel</th>
<th>#</th>
<th>Prijs</th>
<th>Totaal</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<?php if(count($bestellingen) > 0): ?>

<?php $__currentLoopData = $bestellingen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<td>Biefstuk</td>
<td>2</td>
<td>$11</td>
<td>$22</td>
<td>+</td>
<td>-</td>
<td><img style="width: 10px; height: 10px;" src="<?php echo e(URL::to('/assets/trash.png')); ?>"></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    Er zijn geen bestellingen
    <?php endif; ?> 
</table>
</body>
</html><?php /**PATH E:\Examen_k2\resources\views/ober.blade.php ENDPATH**/ ?>