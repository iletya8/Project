<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kok</title>
    <style>
  table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  align: center;
}
th, td {
    text-align: center;
}
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: white;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}
    </style>
</head>
<body>
<div style="background-color: white; border: 1px solid grey; width: 100%; padding: 25px; height:10px; margin-top: 0%;">
    <a style="color: grey; padding-right: 5px;">Home</a>
    <a href="<?php echo e(url('/reserveringen')); ?>" style="color: grey; padding-right: 5px;">Reserveringen</a>
    <div class="dropdown">
  <a style="color: grey; padding-right: 5px;">Serveren ▼</a>
  <div class="dropdown-content">
  <p>Voor kok</p>
  <p>Voor Barman</p>
  <p>Voor Ober</p>
  </div>
</div>
<div class="dropdown">
  <a style="color: grey; padding-right: 5px;">Gegevens ▼</a>
  <div class="dropdown-content">
  <p>Drinken</p>
  <p>Eten</p>
  <p>Klanten</p>
  <p>Gerecht hoofdgroepen</p>
  <p>Gerecht subgroepen</p>
  </div>
</div>
    </div>
    <h4> Klik op het tafelnummer om een bestelling te maken.</h4>
    <h4> | rood = verleden | groen = vandaag | oranje = toekomst |</h4>
<table style="width:70%">
<tr>
<th>Tafel</th>
<th>Aantal</th>
<th>Gerecht</th>
<th>Gereserveerd</th>
</tr>
<tr>
<td>Tafel</td>
<td>aantal</td>
<td>Gerecht</td>
<td>Gereserveerd</td>

</tr>


    </table>
</body>
</html><?php /**PATH E:\Examen_k2\resources\views/kok.blade.php ENDPATH**/ ?>